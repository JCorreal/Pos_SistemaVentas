<html>
    <head>
          <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
          <title>Menu Principal</title>
    </head>
    <body>
          <?php require_once '../vistas/Maestro.php';?>
            <br></br><br></br><br></br>
            <div id="bdcontainer">
                <table border="0" cellpadding="0" cellspacing="10" align="center">
                    <tr>
                        <td><a href="Listado_Categorias.php"><input type="button"  id="bdnav1"></a></td>                  
                        <td><a href="Listado_Productos.php"><input type="button" id="bdnav2"></a></td>
                        <td><a href="Listado_Proveedores.php"><input type="button" id="bdnav3"></a></td>
                    </tr>
                    <tr>
                        <td><a href="Listado_Clientes.php"><input type="button" id="bdnav4"></a></td>
                        <td><a href="Listado_Ventas.php"><input type="button" id="bdnav5"></a></td>
                        <td><a href="ReporteVentas.php"><input type="button" id="bdnav6"></a></td>                                          
                    </tr>   
                </table>
            </div>
    </body>
</html>
