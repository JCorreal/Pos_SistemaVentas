<?php
     
class Controlador_Venta {
   
    protected $idao_venta;
    
    public function __construct(IDao_Venta $idao_venta)
    {
        $this->idao_venta = new Dao_Venta();
    }
    
    public function grabarVenta ($object)
    {     
      return $this->idao_venta->grabarVenta($object);
    }
    
    public function buscar() 
    {
        return $this->idao_venta->buscar();        
    }
    
    public function hacerPedido($venta_id) 
    {
        return $this->idao_venta->hacerPedido($venta_id);        
    }
    
    public function reporte($fechainicio, $fechafin)    
    {
        return $this->idao_venta->reporte($fechainicio, $fechafin);        
    }
    
    
}
