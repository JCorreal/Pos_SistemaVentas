<?php
   
class Controlador_Cliente {
   
    protected $idao_cliente;
        
    public function __construct(IDao_Cliente $idao_cliente)
    {
        $this->idao_cliente = new Dao_Cliente();
    }
        
    public function obtenerCliente($cliente_id)
    {
       return $this->idao_cliente->obtenerCliente($cliente_id);
    }
    
    public function buscar($cliente_id)
    {
        return $this->idao_cliente->buscar($cliente_id);
    }
    
    public function grabarCliente ($object)
    {     
      return $this->idao_cliente->grabarCliente($object);
    }
         
    public function eliminarCliente($cliente_id){        
        return $this->idao_cliente->eliminarCliente($cliente_id);
    }
}
