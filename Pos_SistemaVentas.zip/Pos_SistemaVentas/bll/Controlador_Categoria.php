<?php     
   
class Controlador_Categoria {
   
    protected $idao_categoria;
        
    public function __construct(IDao_Categoria $idao_categoria)
    {
        $this->idao_categoria = new Dao_Categoria();
    }
        
    public function obtenerCategoria($categoria_id)
    {
       return $this->idao_categoria->obtenerCategoria($categoria_id);
    }
    
    public function buscar($categoria_id)
    {
        return $this->idao_categoria->buscar($categoria_id);
    }
    
    public function grabarCategoria ($object)
    {     
      return $this->idao_categoria->grabarCategoria($object);
    }
         
    public function eliminarCategoria($categoria_id){        
        return $this->idao_categoria->eliminarCategoria($categoria_id);
    }

     
}
