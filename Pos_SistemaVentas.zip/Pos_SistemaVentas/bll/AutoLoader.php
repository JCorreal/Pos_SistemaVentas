<?php 
    /* Esto solo funciona en versiones superiores de PHP 5. 
       spl_autoload_register nos facilita la vida para evitar la pesadilla 
       de incluir todos los archivos, que requieren las aplicaciones */

    spl_autoload_register(function ($className) {
    $path = "../bll/$className.php";
    
     if (file_exists($path)) {
         require $path;         
     }
     else
     {
        $path = "../dal/$className.php";
        if (file_exists($path)) {
         require $path;
        }
        else
        { 
           $path = "../form_response/$className.php";
           if (file_exists($path)) {
            require $path;
           }
           else
           {
             $path = "../bo/$className.php";
              if (file_exists($path)) {
                require $path;
               }
               else
               {
                 $path = "../vistas/$className.php";
                 if (file_exists($path)) {
                    require $path;
                  }         
                  else
                  {
                      throw new Exception(sprintf('Clase no hallada.', $className, $path ));
                  }
               }
           }
        }
     }
});
