<?php
    
class Controlador_Proveedor {
   
    protected $idao_proveedor;
        
    public function __construct(IDao_Proveedor $idao_proveedor)
    {
        $this->idao_proveedor = new Dao_Proveedor();
    }
        
    public function obtenerProveedor($proveedor_id)
    {
       return $this->idao_proveedor->obtenerProveedor($proveedor_id);
    }
    
    public function buscar($proveedor_id)
    {
        return $this->idao_proveedor->buscar($proveedor_id);
    }
    
    public function grabarProveedor ($object)
    {     
      return $this->idao_proveedor->grabarProveedor($object);
    }
         
    public function eliminarProveedor($proveedor_id){        
        return $this->idao_proveedor->eliminarProveedor($proveedor_id);
    }

     
}
