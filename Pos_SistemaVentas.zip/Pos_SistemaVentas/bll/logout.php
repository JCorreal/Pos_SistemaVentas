<?php
     session_destroy();
     unset($_SESSION['User_Name']);
     header('location: ../vistas/index.php');
     exit();
