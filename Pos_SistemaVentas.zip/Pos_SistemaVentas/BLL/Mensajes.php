<?php

class Mensajes
{ 
      const MensajeCampoRequerido = " Error, campo es requerido";
      const MensajeIntegridad = " Error, registro relacionado no puede eliminarse";
      const MensajeExiste = " Error, Este registro ya existe";
      const MensajeErrorBD = " Se ha producido un error accesando la base de datos";
      const MensajeCero = " Error, primera cifra no puede ser cero";
      const MensajePrecio = " Error, precio de venta es menor que el de compra";
      const MensajeStock = " Error, cantidad supera el stock disponible";
      const MensajeCantidad = " Error, cantidad debe ser mayor de 0";
      const MensajeMonto = " Error, monto entregado no cancela el total";
      const MensajeTelefono =  "Error, longitud de telefono debe tener 7 o 10 dígitos"; 
      const MensajeNumerico =  "Error, caracteres no numericos en este campo";   
}

      
