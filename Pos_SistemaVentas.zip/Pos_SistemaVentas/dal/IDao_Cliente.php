<?php
 
interface IDao_Cliente {
    
    public function obtenerCliente($cliente_id);   
    public function buscar($cliente_id);   
    public function grabarCliente($cliente);  
    public function eliminarCliente($cliente_id);
}
