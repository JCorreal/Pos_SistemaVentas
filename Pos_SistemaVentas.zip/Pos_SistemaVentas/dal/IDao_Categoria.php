<?php
 
interface IDao_Categoria {
  
   public function obtenerCategoria($categoria_id);   
   public function buscar($categoria_id);   
   public function grabarCategoria($categoria);  
   public function eliminarCategoria($categoria_id);
}
