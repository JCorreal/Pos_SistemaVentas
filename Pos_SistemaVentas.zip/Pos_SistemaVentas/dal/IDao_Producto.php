<?php
 
interface IDao_Producto {
   
    public function obtenerProducto($producto_id);   
    public function buscar($producto_id);   
    public function grabarProducto($producto);  
    public function cargarCombos();
    public function eliminarProducto($producto_id);
}
