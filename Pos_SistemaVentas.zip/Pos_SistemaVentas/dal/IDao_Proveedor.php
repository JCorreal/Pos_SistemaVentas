<?php
 
interface IDao_Proveedor {
    
    public function obtenerProveedor($proveedor_id);   
    public function buscar($proveedor_id);   
    public function grabarProveedor($proveedor);  
    public function eliminarProveedor($proveedor_id);
}
