<?php
 
interface IDao_Venta {   
   public function grabarVenta($venta);
   public function buscar();
   public function hacerPedido($venta_id);
   public function reporte($fechainicio, $fechafin);
}
