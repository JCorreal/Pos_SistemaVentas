<?php
         
class Dao_Cliente extends Dao_General implements IDao_Cliente{
  
  const Source_Clientes =  'tbl_clientes';  
  
  public function obtenerCliente($cliente_id)
  { 
    try
    {
       $vecr = parent::buscarRegistro(Dao_Cliente::Source_Clientes, $cliente_id);
       if ($vecr!= NULL)
       {
         $cliente = new Cliente();
         $cliente->setCliente_id($vecr[0][0]);
         $cliente->setNombre($vecr[0][1]);
         $cliente->setTelefono($vecr[0][2]);
         $cliente->setDireccion($vecr[0][3]);  
         $cliente->setObservacion($vecr[0][4]);  
         unset($vecr);
         return $cliente;
       }
       else
       {
          return NULL;
       }
   }
   catch (Exception $ex)
   {
       echo $ex;
   }      
  }
    public function grabarCliente($cliente)
  { 
     $cn = Conexion::obtenerConexion();    
     try 
     {        
        $cn->query("SET @result = 1");
        $cn->query("CALL SPR_IU_Clientes('" . $cliente->getCliente_id () . "',
                                         '" . $cliente->getNombre() . "',
                                         '" . $cliente->getTelefono() . "', 
                                         '" . $cliente->getDireccion() . "', 
                                         '" . $cliente->getObservacion() . "',                                                                          
                                         @result)");

        $res = $cn->query("SELECT @result AS result");
        $row = $res->fetch_assoc();
        mysqli_close($cn);        
        return $row['result'];          
     }
     catch (Exception $ex)
     {
        mysqli_close($cn);  
        echo $ex;
     }
  }
  
  public function buscar($cliente_id)
  {
     $Lista = array();    
     $Lista =  parent::buscarDatoLista(Dao_Cliente::Source_Clientes, $cliente_id);
     return $Lista;
  }
    public function eliminarCliente($cliente_id) {
      $result = parent::EliminarRegistro(Dao_Cliente::Source_Clientes, $cliente_id);
      return $result;  
    }

}
