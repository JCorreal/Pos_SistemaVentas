<?php

 
interface IDao_Usuario {
    
    public function obtenerAcceso($username, $clave); 
}
